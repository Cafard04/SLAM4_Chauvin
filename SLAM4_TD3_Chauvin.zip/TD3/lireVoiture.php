<?php

require_once'Model.php';
require_once'Voiture.php';
require_once 'trajet.php';


/*Exo6
$rep = Model::$pdo->query('SELECT * FROM voiture', PDO::FETCH_ASSOC);
$tab_obj = $rep->fetchAll(PDO::FETCH_OBJ);

//print_r($tab_obj);

*/

//Exo7
//print_r($rep);
//$users = $pdo->query('SELECT name FROM users')->fetchAll(PDO::FETCH_CLASS, 'User');
/*$rep = Model::$pdo->query('SELECT * FROM voiture');
$rep->setFetchMode(PDO::FETCH_CLASS, 'Voiture');
$tab_voit = $rep->fetchAll();


foreach ($tab_voit as $value){
    $value->afficher();
}
*/



foreach (Voiture::getAllVoitures() as $value){
    $value->afficher();
}


echo "<br>";
echo "<br>";

Voiture::getVoitureByImmat("XX2558XX")->afficher();

Voiture::save("Fiat","Bleu","AA258AA");
