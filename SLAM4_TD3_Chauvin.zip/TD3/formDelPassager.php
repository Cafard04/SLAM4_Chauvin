<form method="post" action="testDelPassager.php">
 <fieldset>
 <legend>Mon formulaire :</legend>
 
    <p>
 <label for="id_trajet">ID Trajet</label> :
 <input type="text" placeholder="Ex : 6" name="data[0]" id="id_trajet" required/>

 </p>
      <p>
 <label for="id_user">ID Utilisateur</label> :
 <input type="text" placeholder="Ex : us6" name="data[1]" id="id_user" required/>
 
 </p>
 

 
       <p>
 <input type="submit" value="Envoyer" />
 </p>
 </fieldset>
</form>