<form method="post" action="testDelPassager.php">
 <fieldset>
 <legend>Mon formulaire :</legend>
 
    <p>
 <label for="id_trajet">ID Trajet</label> :
 <input type="text" placeholder="Ex : 6" name="id_trajet" id="id_trajet" required/>
 </p>
      <p>
 <label for="id_user">ID Utilisateur</label> :
 <input type="text" placeholder="Ex : us6" name="id_user" id="id_user" required/>
 </p>
 

 
       <p>
 <input type="submit" value="Envoyer" />
 </p>
 </fieldset>
</form>