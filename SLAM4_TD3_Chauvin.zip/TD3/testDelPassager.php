<?php

require_once 'trajet.php';

if (empty($_POST['id_user']) ){
    echo "donn�e manquante";
}
else {
    echo "L'utilisateur ".$_POST['id_user']. " a �t� supprim� du trajet n�".$_POST['id_trajet'];
    Trajet::deletePassager($_POST['id_trajet'],$_POST['id_user'])->afficher();
}
