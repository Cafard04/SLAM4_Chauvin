<form method="post" action="testFindTraj.php">
 <fieldset>
 <legend>Mon formulaire :</legend>
 
      <p>
 <label for="id_user">ID Utilisateur</label> :
 <input type="text" placeholder="Ex : us6" name="id_user" id="id_user" required/>
 </p>
       <p>
 <input type="submit" value="Envoyer" />
 </p>
 </fieldset>
</form>