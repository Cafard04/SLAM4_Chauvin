<?php

require_once 'Model.php';
class Voiture{


 private $marque;
 private $couleur;
 private $immatriculation;

 // un getter
 public function getMarque() {
 return $this->marque;
 }

 // un setter
 public function setMarque($marque2) {
 $this->marque = $marque2;
 }
    
 // un getter
 public function getCouleur() {
 return $this->couleur;
 }

 // un setter
 public function setCouleur($couleur2) {
 $this->couleur = $couleur2;
 }

     // un getter
 public function getImmatriculation() {
    
 return $this->immatriculation;
 }

 // un setter
 public function setImmatriculation($immatriculation) {
      if (strlen($immatriculation)>8){
         $immatriculation = substr($immatriculation,0,8);
     }
    $this->immatriculation = $immatriculation;
 }


 // un constructeur
public function __construct($m = NULL, $c = NULL, $i = NULL) {
        if (!is_null($m) && !is_null($c) && !is_null($i)) {
            $this->marque = $m;
            $this->couleur = $c;
            $this->immatriculation = $i; 
            
        } 
    }


 // une methode d'affichage.
 public function afficher() {
 
     echo $this -> marque." ";
     echo $this -> couleur." ";
     echo $this -> immatriculation." ";
     echo "<br>";
     
 }
 
 
 public static function save($marque, $couleur, $immatriculation){
    $sql="INSERT INTO voiture VALUES (:marque_tag, :couleur_tag, :immatriculation_tag)";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "marque_tag" => $marque,
        "couleur_tag" => $couleur,
        "immatriculation_tag" =>$immatriculation
    );
    $req_prep->execute($values);
 }
 
 
 public static function getAllVoitures(){
     $rep = Model::$pdo->query('SELECT * FROM voiture'); 
     $rep->setFetchMode(PDO::FETCH_CLASS, 'Voiture'); 
      return $tab_voit = $rep->fetchAll();

 }
 
 public static function getVoitureByImmat($immatriculation) {
    $sql = "SELECT * from voiture WHERE immatriculation=:nom_tag";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "nom_tag" => $immatriculation
    );
    $req_prep->execute($values);
    $req_prep->setFetchMode(PDO::FETCH_CLASS, 'Voiture');
    $tab_voit = $req_prep->fetchAll();
    if (empty($tab_voit)){
        return false;
    }
    return $tab_voit[0];
}

   /* 
function getVoitureByImmat2($immat) {
 $sql = "SELECT * from voiture2 WHERE immatriculation='$immat'";
 $rep = Model::$pdo->query($sql);
 $rep->setFetchMode(PDO::FETCH_CLASS, 'Voiture');
 return $rep->fetch();
}
*/

   
}


    
