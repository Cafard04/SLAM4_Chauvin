<form method="post" action="testFindUtil.php">
 <fieldset>
 <legend>Mon formulaire :</legend>
 
      <p>
 <label for="id_trajet">ID</label> :
 <input type="text" placeholder="Ex : 6" name="id_trajet" id="id_trajet" required/>
 </p>
       <p>
 <input type="submit" value="Envoyer" />
 </p>
 </fieldset>
</form>