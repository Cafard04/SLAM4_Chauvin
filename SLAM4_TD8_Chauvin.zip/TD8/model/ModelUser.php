<?php

require_once (File::build_path(array("model", "Model.php")));

class ModelUser extends Model {                                                  //extension du Model

    private $login;
    private $nom;
    private $prenom;
    private $admin;
    private $email;
    private $mdp;
    private $nonce;
    protected static $object = 'user';                                             //objet r�utilis� dans le Model pour d�finir le nom de la table
    protected static $primary = 'login';                                            //objet r�utilis� dans le Model pour d�finir la cl� primaire

    // un getter
    public function getLogin() {
        return $this->login;
    }

    // un setter
    public function setLogin($login2) {
        $this->login = $login2;
    }

    // un getter
    public function getNom() {
        return $this->nom;
    }

    // un setter
    public function setNom($nom2) {
        $this->nom = $nom2;
    }

    // un getter
    public function getPrenom() {

        return $this->prenom;
    }

    // un setter
    public function setPrenom($prenom) {

        $this->prenom = $prenom;
    }

      // un getter
    public function getRole() {

        return $this->admin;
    }

    // un setter
    public function setRole($admin) {

        $this->admin = $admin;
    }
    
      // un getter
    public function getEmail() {

        return $this->email;
    }

    // un setter
    public function setEmail($email) {

        $this->email = $email;
    }
    
    
      // un getter
    public function getMdp() {

        return $this->mdp;
    }

    // un setter
    public function setMdp($mdp) {

        $this->mdp = $mdp;
    }
    
        
      // un getter
    public function getNonce() {

        return $this->nonce;
    }

    // un setter
    public function setNonce($nonce) {

        $this->nonce = $nonce;
    }
    
    
    
    // un constructeur
    public function __construct($l = NULL, $n = NULL, $p = NULL) {
        if (!is_null($l) && !is_null($n) && !is_null($p)) {
            $this->login = $l;
            $this->nom = $n;
            $this->prenom = $p;
        }
    }

    public static function checkPassword($login, $mpd) {
        $login = $_SESSION['login'];
        $mdp = $_SESSION['mdp'];

        
        $sql = "SELECT * FROM user WHERE login=:login_tag AND mdp=:mdp_tag";
        $req_prep = Model::$pdo->prepare($sql);
        $values = array(
            "login_tag" => $login,
            "mdp_tag" => chiffrer($mdp)
           
        );
        $req_prep->execute($values);
        $count = $req_prep->rowCount();
                
        if ($count==1){
            return true;
        } else {return false;}
        

    }
    
    
    
    
    /*public static function admin($login){
        $login = $_SESSION['login'];
        
        $sql = "SELECT admin FROM user WHERE login=:login_tag";
        $req_prep = Model::$pdo->prepare($sql);
        $values = array(
            "login_tag" => $login,
                       
        );
        $req_prep->execute($values);
                        
    }*/

    /*
      public static function save($login, $nom, $prenom){                            //une fonction qui insert un tuple dans la bdd
      $login=$_POST['login'];
      $nom=$_POST['data'][0];
      $prenom=$_POST['data'][1];

      $sql="INSERT INTO user VALUES (:login_tag, :nom_tag, :prenom_tag)";
      $req_prep = Model::$pdo->prepare($sql);
      $values = array(
      "nom_tag" => $nom,
      "prenom_tag" => $prenom,
      "login_tag" =>$login
      );
      $req_prep->execute($values);
      }
     */
}
