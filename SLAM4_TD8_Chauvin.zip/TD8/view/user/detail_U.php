
<?php

echo '<p> utilisateur :  ' . htmlspecialchars($tab_v->getNom()) . ' ' . htmlspecialchars($tab_v->getPrenom()) . '. </p>';
if (!empty($_SESSION['login'])){
if (Session::is_user($_SESSION['login'])==true){
echo '<a href="index.php?controller=user&action=delete&login=' . $tab_v->getLogin() . '">Supprimer cet user</a>';
echo '<br><a href="index.php?controller=user&action=update&login=' . $tab_v->getLogin() . '">Modifier cet user</a>';
}
} 
       
        

                //si dessus les liens pour rediriger vers d'autres actions
                
