<!-- cette page est commune � 2 actions cr�er et modifier, on insere donc des conditions -->
<form method="post" action="index.php?controller=user&action=<?= static::$action ?><?php if (static::$action =='updated') echo '&login='.$_GET['login'];?>">
                                                                                <!-- l'action change selon la donn�e rentr�e dans la m�me varibale d�finie dans le controller -->
   <fieldset>
 <legend>Mon formulaire :</legend>
 <p>
 <label for="log">Login</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $_GET['login']; ?>" name="data[login]" id="login" <?= static::$type?>/>
 </p>                                                                           <!--  si l'action est "updated alors on affiche une donn�e-->
                                                                                <!-- on change �galement le type de l'input readonly ou required-->
      <p>
 <label for="nom">Nom</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $tab_v->getNom()?>" name="data[nom]" id="nom " required/>
 </p>                                                                           <!-- on stocke la donn�e dans un tableau -->
      <p>
 <label for="prenom">Prenom</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $tab_v->getPrenom()?>" name="data[prenom]" id="prenom" required/>
 </p>
     
       <p>
 <label for="prenom">Email</label> :
 <input type="email" value="<?php if (static::$action =="updated") echo $tab_v->getEmail()?>" name="data[email]" id="email" required/>
    <!-- le type email require un @-->
       </p>
 
       <p>
 <label for="mdp">Mot de passe</label> :
 <input type="password" value="<?php if (static::$action =="updated") echo "*****"?>" name="data[mdp]" id="mdp" required/>
 </p>
     
       <p>
 <label for="mdp2">Confirmer le mot de passe</label> :
 <input type="password" value="<?php if (static::$action =="updated") echo "*****"?>" name="mdp2" id="mdp2" required/>
 </p>
   
 
    <input type="checkbox" name="admin[]" value="good" <?php if (static::$action =="updated" && $tab_v->getRole()==1) echo "checked" ?> />Administrateur ?<br>



 

 <p>
 <input type="submit" value="Envoyer" />
 </p>
 </fieldset>
</form>


