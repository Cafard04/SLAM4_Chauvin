<!-- cette page est commune � 2 action cr�er et modifier, on insere donc des conditions -->
<form method="post" action="index.php?controller=user&action=connected">
                                                                                <!-- l'action change selon la donn�e rentr�e dans la m�me varibale d�finie dans le controller -->
   <fieldset>
 <legend>Connection :</legend>
 <p>
 <label for="log">Login</label> :
 <input type="text" placehorder="Login" name="login" id="login" required/>
 </p>                                                                           <!--  si l'action est "updated alors on affiche une donn�e-->
                                                                                <!-- on change �galement le type de l'input readonly ou required-->
           <p>
 <label for="mdp">Mot de passe</label> :
 <input type="password" placehorder="123456789" name="mdp" id="mdp" required/>
 </p>
     
     

 <p>
 <input type="submit" value="Connexion" />
 </p>
 </fieldset>
</form>



