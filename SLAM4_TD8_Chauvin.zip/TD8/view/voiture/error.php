<?php
echo $_SESSION['login'];
echo $_SESSION['mdp'];
echo "Page introuvable";