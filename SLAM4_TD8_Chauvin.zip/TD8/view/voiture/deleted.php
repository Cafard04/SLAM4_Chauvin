<?php

echo '<p> Voiture effac�e avec succ�s.</p>';