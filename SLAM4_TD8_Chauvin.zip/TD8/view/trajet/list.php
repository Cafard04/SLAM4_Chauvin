
 <?php

     foreach ($tab_v as $v ){

        echo '<p> Trajet : <a href="index.php?controller=trajet&action=read&id='.rawurlencode($v->getId()).'">'. htmlspecialchars($v->getdateT()).'</a>.';
        //on prot�ge notre code gr�ce au methode rawurlencode() et htmlspecialcar()
   }


 ?>

