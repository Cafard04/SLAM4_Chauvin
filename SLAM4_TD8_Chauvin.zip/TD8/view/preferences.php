
<form method="POST" action="view/personnalisation.php">
<div>
  <input type="radio" id="trajet" name="choix" value="trajet"
         checked>
  <label for="trajet">Trajet</label>
</div>

<div>
  <input type="radio" id="user" name="choix" value="user">
  <label for="user">User</label>
</div>

<div>
  <input type="radio" id="voiture" name="choix" value="voiture">
  <label for="voiture">Voitures</label>
</div>
    
 <p>
 <input type="submit" value="Envoyer" />
 </p>
</form>


