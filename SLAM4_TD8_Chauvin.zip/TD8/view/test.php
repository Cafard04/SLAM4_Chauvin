<form method="get"> 
            <div class="checkbox"> 
                <label><input type="checkbox" name = "option1" 
                        value="Option 1">Option 1</label> 
                <label><button name="submit" value='true' 
                    class="btn btn-default">SUBMIT</button> 
            </div> 
        </form> 