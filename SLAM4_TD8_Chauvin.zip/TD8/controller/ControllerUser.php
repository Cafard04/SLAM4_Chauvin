<?php

require_once (File::build_path(array("model", "ModelUser.php"))); // chargement du mod�le

class ControllerUser {

    protected static $object = 'user';
    protected static $action;
    protected static $type;

    public static function readAll() {
        $tab_v = ModelUser::selectAll(); //appel au mod�le pour gerer la BD
        $controller = static::$object;
        $view = 'list';
        $pagetitle = 'Liste des users';
        require (File::build_path(array("view", "view.php"))); //"redirige" vers la vue
    }

    public static function read() {
        $controller = static::$object;
        $view = 'detail_U';
        $pagetitle = 'D�tail des users';
        $tab_v = ModelUser::select($_GET['login']); //appel au mod�le pour gerer la BD

        if ($_GET['login'] == NULL) {
            require (File::build_path(array("view", "voiture", "error.php"))); //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "view.php"))); //"redirige" vers la vue
        }
    }

    public static function delete() {

        if (!empty($_SESSION['login']) && Session::is_user($_SESSION['login']) == true && Session::is_admin()) {        //is_user et is_admin v�rifie si l'utilisateur a les droits pour ces actions
            $controller = static::$object;
            $view = 'deleted_U';
            $pagetitle = 'Suppression d\'un user';

            $tab_v = ModelUser::delete($_GET['login']);
        } else {
            $controller = 'user';
            $view = 'connect';
            $pagetitle = 'Connexion';
            require (File::build_path(array("view", "view.php")));
        }

        require (File::build_path(array("view", "view.php"))); //"redirige" vers la vue
    }

    public static function create() {
        if (!empty($_SESSION['login']) && Session::is_user($_SESSION['login']) == true && Session::is_admin()) {
            static::$action = 'created';
            static::$type = 'required';
            $controller = 'user';
            $view = 'update_U';
            $pagetitle = 'Connexion';
        } else {
            $controller = 'user';
            $view = 'connect';
            $pagetitle = 'Connexion';
        }
        require (File::build_path(array("view", "view.php")));
    }

    public static function created() {
        if (!empty($_SESSION['login']) && Session::is_user($_SESSION['login']) == true && Session::is_admin()) {
            $controller = static::$object;
            $view = 'created_U';
            $pagetitle = 'Cr�ation des users';
            
           //filter_var($email, FILTER_VALIDATE_EMAIL);                           //est cens� v�rifier si le mail est au bon format


            ModelUser::save($_POST['data']);
            $tab_v = ModelUser::selectAll();
        } else {
            $controller = 'user';
            $view = 'connect';
            $pagetitle = 'Connexion';
        }
        require (File::build_path(array("view", "view.php")));
    }

    public static function updated() {

        if (!empty($_SESSION['login']) && Session::is_user($_SESSION['login']) == true && Session::is_admin()) {
            static::$action = 'updated';
            static::$type = 'readonly';
            $controller = 'user';
            $view = 'update_U';
            $pagetitle = 'Modification d\'un user';

            ModelUser::update($_POST['data'], $_GET['login']);
            $tab_v = ModelUser::select($_GET['login']);
        } else {
            $controller = 'user';
            $view = 'connect';
            $pagetitle = 'Connexion';
        }
        require (File::build_path(array("view", "view.php")));
    }

    public static function update() {
        static::$action = 'updated';
        static::$type = 'readonly';


        if (!empty($_SESSION['login']) && Session::is_user($_SESSION['login']) == true && Session::is_admin()) {
            $controller = static::$object;
            $view = 'update_U';
            $pagetitle = 'Modification d\'un user';

            $tab_v = ModelUser::select($_GET['login']);
        } else {
            $controller = 'user';
            $view = 'connect';
            $pagetitle = 'Connexion';
        }
        require (File::build_path(array("view", "view.php")));
    }

    public static function connect() {
        $controller = static::$object;
        $view = 'connect';
        $pagetitle = 'Connexion';


        require (File::build_path(array("view", "view.php"))); //"redirige" vers la vue
    }

    public static function connected() {
        $controller = static::$object;
        $view = 'detail_U';
        $pagetitle = 'Connexion';

        $_SESSION['login'] = $_POST['login'];
        $_SESSION['mdp'] = $_POST['mdp'];
       // $_SESSION['admin'] = ModelUser::admin($_SESSION['login']);

        if (ModelUser::checkPassword($_SESSION['login'], $_SESSION['mdp']) == false) {
            $tab_v = ModelUser::select($_SESSION['login']);
            $_SESSION['admin'] = $tab_v->getRole();
            if ($tab_v->getNonce() == NULL){                                    //on v�rifie si le nonce est null pour autoriser la cnx
            require (File::build_path(array("view", "view.php"))); //"redirige" vers la vue
            }
            else {
                 require (File::build_path(array("view", "user", "connect.php"))); //"redirige" vers la vue
            }
        } else {
            require (File::build_path(array("view", "user", "connect.php"))); //"redirige" vers la vue
        }
    }

    public static function deconnect() {
        $controller = static::$object;
        $view = 'connect';
        $pagetitle = 'Connexion';

        unset($_SESSION['login']);
        unset($_SESSION['mdp']);
        unset($_SESSION['admin']);
        require (File::build_path(array("view", "view.php"))); //"redirige" vers la vue
    }

}
