<?php
class Trajet {

    private $id;
    private $depart;
    private $arrivee;
    private $dateT;
    private $nbplace;
    private $cond_login;
    private $prix;

 // un getter
 public function getId() {
 return $this->id;
 }

 // un setter
 public function setId($id2) {
 $this->id = $id2;
 }
    
 // un getter
 public function getDepart() {
 return $this->depart;
 }

 // un setter
 public function setDepart($depart2) {
 $this->depart = $depart2;
 }

    // un getter
 public function getArrivee() {
    
 return $this->arrivee;
 }

 // un setter
 public function setArrivee($arrivee2) {
     
 $this->arrivee = $arrivee2;
 }

        // un getter
 public function getDateT() {
    
 return $this->dateT;
 }

 // un setter
 public function setDateT($dateT2) {
     
 $this->dateT = $dateT2;
 }
    
        // un getter
 public function getNbplace() {
    
 return $this->nbplace;
 }

 // un setter
 public function setNbplace($nbplace2) {
     
 $this->nbplace = $nbplace2;
 }
    
        
        // un getter
 public function getCondLog() {
    
 return $this->cond_log;
 }

 // un setter
 public function setCondLog($cond_log2) {
     
 $this->cond_log = $cond_log2;
 }
    
            // un getter
 public function getPrix() {
    
 return $this->prix;
 }

 // un setter
 public function setPrix($prix2) {
     
 $this->prix = $prix2;
 }

 // un constructeur

 public function __construct($i = NULL, $d = NULL, $a = NULL, $dt = NULL, $n = NULL, $c = NULL, $p = NULL) {
        if (!is_null($i) && !is_null($d) && !is_null($a)&& !is_null($dt)&& !is_null($n)&& !is_null($c)&& !is_null($p)) {
             $this->id = $i;
             $this->depart = $d;
             $this->arrivee = $a;
             $this->dateT = $d;
             $this->nbplace = $n;
             $this->cond_log = $c;
             $this->prix = $p;
            
        } 
    }

 // une methode d'affichage.
 public function afficher() {
 
     echo $this -> id." ";
     echo $this -> depart." ";
     echo $this -> arrivee." ";
     echo $this -> dateT." ";
     echo $this -> nbplace." ";
     echo $this -> cond_log." ";
     echo $this -> prix." ";
     echo "<br>";
     
 }
 
 
  
 
  public static function getAllTrajets(){
     $rep = Model::$pdo->query('SELECT * FROM trajet'); 
     $rep->setFetchMode(PDO::FETCH_CLASS, 'trajet'); 
      return $tab_tr = $rep->fetchAll();




 }
    
   
}