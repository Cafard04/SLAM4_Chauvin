<?php
require_once "Model.php";
echo "Connexion réussie !" ;
