<!-- cette page est commune � 2 action cr�er et modifier, on insere donc des conditions -->
<form method="post" action="index.php?controller=user&action=<?= static::$action ?><?php if (static::$action =="updated") echo '&login='.$_GET['login'];?>">
                                                                                <!-- l'action change selon la donn�e rentr�e dans la m�me varibale d�finie dans le controller -->
   <fieldset>
 <legend>Mon formulaire :</legend>
 <p>
 <label for="log">Login</label> :
 <input type="text" placeholder="<?php if (static::$action =="updated") echo $_GET['login']; ?>" name="login" id="login" <?= static::$type?>/>
 </p>                                                                           <!--  si l'action est "updated alors on affiche une donn�e-->
                                                                                <!-- on change �galement le type de l'input readonly ou required-->
      <p>
 <label for="nom">Nom</label> :
 <input type="text" placeholder="<?php if (static::$action =="updated") echo $tab_v->getNom()?>" name="data[0]" id="nom " required/>
 </p>                                                                           <!-- on stocke la donn�e dans un tableau -->
      <p>
 <label for="prenom">Prenom</label> :
 <input type="text" placeholder="<?php if (static::$action =="updated") echo $tab_v->getPrenom()?>" name="data[1]" id="prenom" required/>
 </p>
     

 <p>
 <input type="submit" value="Envoyer" />
 </p>
 </fieldset>
</form>


