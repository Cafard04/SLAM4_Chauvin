
 <?php

        echo '<p> utilisateur :  ' . htmlspecialchars($tab_v->getNom()). ' '.htmlspecialchars($tab_v->getPrenom()).'. </p>'.
                 '<a href="index.php?controller=user&action=delete&login='.$tab_v->getLogin().'">Supprimer cet user</a>'
                . '<br><a href="index.php?controller=user&action=update&login='.$tab_v->getLogin().'">Modifier cet user</a>';
                //si dessus les liens pour rediriger vers d'autres actions
                
