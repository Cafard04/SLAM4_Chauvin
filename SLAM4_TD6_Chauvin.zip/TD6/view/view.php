<!DOCTYPE html>
<html>
 <head>
 <meta charset="UTF-8">
 <title><?php echo $pagetitle; ?></title>
 </head>
 <header>
     <ul>
         <li><a href="index.php?controller=voiture&action=readAll">Liste voitures</a></li>
         <li><a href="index.php?controller=user&action=readAll">Liste utilisateurs</a></li>
         <li><a href="index.php?action=readAll&controller=trajet">Liste trajet</a></li>
     </ul>
     
 </header>
 <body>
     
      <h1><?php echo $pagetitle; ?> </h1>
      
<?php
// Si $controleur='voiture' et $view='list',
// alors $filepath="/chemin_du_site/view/voiture/list.php"
$filepath = File::build_path(array("view", $controller, "$view.php"));
require $filepath;
?>
      
      <p style="border: 1px solid black;text-align:right;padding-right:1em;">
 Site de covoiturage de ...
</p>

 </body>
</html>