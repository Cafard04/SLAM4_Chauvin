
 <?php

        echo '<p> Voiture ' . htmlspecialchars($tab_v->getImmatriculation()). '.</p>'. 
                '<a href="index.php?controller=voiture&action=delete&immatriculation='.$tab_v->getImmatriculation().'">Supprimer cette voiture</a>'
                . '<br><a href="index.php?controller=voiture&action=update&immatriculation='.$tab_v->getImmatriculation().'">Modifier cette voiture</a>';
