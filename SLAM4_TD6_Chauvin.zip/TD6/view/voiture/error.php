<?php
echo $_GET['immatriculation'];
print_r($_POST['data']);
echo "Page introuvable";