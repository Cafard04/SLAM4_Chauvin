<?php 
/*
*
*
*
la classe controllerTrajet est comment�e en guise de mod�le pour celle-ci et controllerVoiture
*
*
*
*/


require_once (File::build_path(array("model", "ModelUser.php"))); // chargement du mod�le

class ControllerUser {
    
    protected static $object = 'user';
        protected static $action;
    protected static $type;
    
    public static function readAll() {
        $tab_v = ModelUser::selectAll(); //appel au mod�le pour gerer la BD
        $controller=static::$object;
        $view='list';
        $pagetitle='Liste des users';
        require (File::build_path(array("view", "view.php"))); //"redirige" vers la vue
    }
    
        
    public static function read() {
        $controller=static::$object;
        $view='detail_U';
        $pagetitle='D�tail des users';
        $tab_v = ModelUser::select($_GET['login']); //appel au mod�le pour gerer la BD
       
        if ($_GET['login']==NULL){
            require (File::build_path(array("view","voiture", "error.php")));//"redirige" vers la vue
        } else {
             require (File::build_path(array("view","user", "detail_U.php")));//"redirige" vers la vue
        }
      
        
    }
    
    
    public static function delete() {
        $controller = static::$object;
        $view = 'deleted_U';
        $pagetitle = 'Suppression d\'un user';

        $tab_v = ModelUser::delete($_GET['login']);

        if ($_GET['login'] == NULL) {
            require (File::build_path(array("view", "voiture", "error.php"))); //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "user", "deleted_U.php"))); //"redirige" vers la vue
        }
    }
    
    
     public static function create() {
        static::$action='created';
        static::$type ='required';
        
        require (File::build_path(array("view", "user", "update_U.php")));
    }

     public static function created() {
        $controller =static::$object;
        $view = 'created';
        $pagetitle = 'Cr�ation des users';

        ModelUser::save($_POST['data']);
        $tab_v = ModelUser::selectAll();
        require (File::build_path(array("view", "user", "created_U.php")));
    }
    
    
    public static function updated() {
        static::$action='updated';
        static::$type ='readonly';
        $controller = 'user';
        $view = 'update';
        $pagetitle = 'Modification d\'un user';
        
        ModelUser::update($_POST['data'],$_GET['login']);
        $tab_v = ModelUser::select($_GET['login']);

        if ($_GET['login'] == NULL) {
            require (File::build_path(array("view", "user", "error.php")));  //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "user", "update_U.php")));
        }
    }

    public static function update() {
        static::$action='updated';
        static::$type ='readonly';
        
        
        
      $controller = static::$object;
      $view = 'update';
      $pagetitle = 'Modification d\'un user';

      $tab_v = ModelUser::select($_GET['login']);
      require (File::build_path(array("view", "user", "update_U.php")));
      

   
      }
    

    
    
    
   }
