<?php

/*
*
*
*
la classe controllerTrajet est comment�e en guise de mod�le pour celle-ci et controllerVoiture
*
*
*
*/

require_once (File::build_path(array("model", "ModelVoiture.php")));            // chargement du mod�le

class ControllerVoiture {

    protected static $object = 'voiture';
    protected static $action;
    protected static $type;



    public static function readAll() {                                      
        $tab_v = ModelVoiture::selectAll();                                     //appel au mod�le pour gerer la BD
        $controller = static::$object;
        $view = 'list';
        $pagetitle = 'Liste des voitures';
        require (File::build_path(array("view", "view.php")));                  //"redirige" vers la vue
    }

    public static function read() {
        $controller = static::$object;
        $view = 'detail';
        $pagetitle = 'D�tail des voitures';
        $tab_v = ModelVoiture::select($_GET['immatriculation']);                //appel au mod�le pour gerer la BD

        if ($_GET['immatriculation'] == NULL) {
            require (File::build_path(array("view", "voiture", "error.php")));  //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "voiture", "detail.php"))); //"redirige" vers la vue
        }
    }

    public static function delete() {
        $controller = static::$object;
        $view = 'deleted';
        $pagetitle = 'Suppression d\'une voitures';

        $tab_v = ModelVoiture::delete($_GET['immatriculation']);

        if ($_GET['immatriculation'] == NULL) {
            require (File::build_path(array("view", "voiture", "error.php")));  //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "voiture", "deleted.php")));//"redirige" vers la vue
        }
    }

    public static function erreur() {
        require (File::build_path(array("view", "voiture", "error.php")));
    }

    public static function create() {
        static::$action='created';
        static::$type ='required';
        
        require (File::build_path(array("view", "voiture", "update.php")));
    }

     public static function created() {
        $controller = 'voiture';
        $view = 'created';
        $pagetitle = 'Cr�ation des voitures';

        ModelVoiture::save($_POST['data']);
        $tab_v = ModelVoiture::selectAll();
        require (File::build_path(array("view", "voiture", "created.php")));
    }
    
    
    public static function updated() {
        static::$action='updated';
        static::$type ='readonly';
        $controller = 'voiture';
        $view = 'update';
        $pagetitle = 'Modification d\'une voiture';
        
        ModelVoiture::update($_POST['data'],$_GET['immatriculation']);
        $tab_v = ModelVoiture::select($_GET['immatriculation']);

        if ($_GET['immatriculation'] == NULL) {
            require (File::build_path(array("view", "voiture", "error.php")));  //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "voiture", "update.php")));
        }
    }

    
    public static function save() {
        static::$action='save';
        $controller = 'voiture';
        $view = 'create';
        $pagetitle = 'Modification d\'une voiture';
        
        ModelVoiture::save($_POST['data']);
        $tab_v = ModelVoiture::selectAll();

        if ($_GET['immatriculation'] == NULL) {
            require (File::build_path(array("view", "voiture", "error.php")));  //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "voiture", "list.php")));
        }
    }
    
    
    
    public static function update() {
        static::$action='updated';
        static::$type ='readonly';
        
        
        
      $controller = 'voiture';
      $view = 'update';
      $pagetitle = 'Modification d\'une voitures';

      $tab_v = ModelVoiture::select($_GET['immatriculation']);
      require (File::build_path(array("view", "voiture", "update.php")));
      

     
      }
    


   

}
