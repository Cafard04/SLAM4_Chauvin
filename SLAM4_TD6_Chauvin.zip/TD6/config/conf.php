<?php
//cette classe permet de définir les paramètres de conexion à la database
class Conf {

 static private $databases = array(
 'hostname' => 'localhost',
 'database' => 'slam4_revisions',
 'login' => 'root',
 'password' => '');

 static public function getHostname() {
    return self::$databases['hostname'];
 }
 
  static public function getDatabase() {
   return self::$databases['database'];
 }
  static public function getPassword() {
    return self::$databases['password'];
 }
 
 static public function getLogin() {
 return self::$databases['login'];
 }
 
 static private $debug = True; 
 static public function getDebug() { 
     return self::$debug; 
     
 }

}
