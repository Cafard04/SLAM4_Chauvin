<?php

require_once (File::build_path(array("model", "Model.php")));

class ModelVoiture extends Model{


 private $marque;
 private $couleur;
 private $immatriculation;
 protected static $object= 'voiture';
 protected static $primary='immatriculation';

 // un getter
 public function getMarque() {
 return $this->marque;
 }

 // un setter
 public function setMarque($marque2) {
 $this->marque = $marque2;
 }
    
 // un getter
 public function getCouleur() {
 return $this->couleur;
 }

 // un setter
 public function setCouleur($couleur2) {
 $this->couleur = $couleur2;
 }

     // un getter
 public function getImmatriculation() {
    
 return $this->immatriculation;
 }

 // un setter
 public function setImmatriculation($immatriculation) {
      if (strlen($immatriculation)>8){
         $immatriculation = substr($immatriculation,0,8);
     }
    $this->immatriculation = $immatriculation;
 }


 // un constructeur
public function __construct($m = NULL, $c = NULL, $i = NULL) {
        if (!is_null($m) && !is_null($c) && !is_null($i)) {
            $this->marque = $m;
            $this->couleur = $c;
            $this->immatriculation = $i; 
            
        } 
      
    }

/*
 // une methode d'affichage.
 public function afficher() {
 
     echo $this -> marque." ";
     echo $this -> couleur." ";
     echo $this -> immatriculation." ";
     echo "<br>";
     
 }
 */
 
 public static function save($immatriculation, $marque, $couleur){              //une fonction qui insert un tuple dans la bdd
    $immatriculation=$_POST['immatriculation'];
    $marque=$_POST['data'][0];
    $couleur=$_POST['data'][1];
    
    $sql="INSERT INTO voiture VALUES (:immatriculation_tag, :marque_tag, :couleur_tag)";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "marque_tag" => $marque,
        "couleur_tag" => $couleur,
        "immatriculation_tag" =>$immatriculation
    );
    $req_prep->execute($values);
 }
 
 /*
public static function updated($data){                                          //fonction qui met � jour des champs selon un id pass� en param�tre
    $immat_id=$_GET['immatriculation'];
    $marq_id=$_POST['data'][0];
    $cou_id=$_POST['data'][1];
    
    $sql="UPDATE voiture SET immatriculation=:immat_tag, marque=:marq_tag, couleur=:cou_tag WHERE immatriculation=:immat_tag";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "immat_tag" => $immat_id,
        "marq_tag" => $marq_id,
        "cou_tag" => $cou_id
    );
    $req_prep->execute($values);
}
*/
 /* //On g�n�ralise avec le selectAll() dans model.php
 public static function getAllVoitures(){
     $rep = Model::$pdo->query('SELECT * FROM voiture'); 
     $rep->setFetchMode(PDO::FETCH_CLASS, 'ModelVoiture'); 
      return  $rep->fetchAll();

 }*/

 public static function getVoitureByImmat($immatriculation) {                   //fonction qui selectionne les champs selon un id pass� en param�tre
    $sql = "SELECT * from voiture WHERE immatriculation=:nom_tag";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "nom_tag" => $immatriculation
    );
    $req_prep->execute($values);
    $req_prep->setFetchMode(PDO::FETCH_CLASS, 'ModelVoiture');
    $tab_voit = $req_prep->fetchAll();
    if (empty($tab_voit)){
        return false;
    }
    return $tab_voit[0];
}

/*
 public static function deleteByImmat($immatriculation) {                       //fonction qui met � jour des champs selon un id pass� en param�tre
    $sql = "DELETE FROM voiture WHERE immatriculation=:nom_tag";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "nom_tag" => $immatriculation
    );
    $req_prep->execute($values);
    $req_prep->setFetchMode(PDO::FETCH_CLASS, 'ModelVoiture');
    $tab_voit = $req_prep->fetchAll();
    if (empty($tab_voit)){
        return false;
    }
    return $tab_voit[0];
}
*/
 public static function updatefi($immatriculation,$marque,$couleur) {           //fonction qui met � jour des champs selon un id pass� en param�tre
    $sql = "UPDATE voiture SET immatriculation=:immatriculation_tag, marque=:marque_tag, couleur=:couleur_tag WHERE immatriculation=:immatriculation_tag";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "marque_tag" => $marque,
        "couleur_tag" => $couleur,
        "immatriculation_tag" =>$immatriculation
    );
    $req_prep->execute($values);
}





 
   
}


    
