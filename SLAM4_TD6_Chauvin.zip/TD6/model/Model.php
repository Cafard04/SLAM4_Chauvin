<?php

require_once (File::build_path(array("config", "conf.php")));

class Model {

    public static $pdo;

    public static function Init() {
        $hostname = Conf::getHostname();
        $database = Conf::getDatabase();
        $login = Conf::getLogin();
        $password = Conf::getPassword();

        try {
            //new PDO("mysql:host=$hostname;dbname=$database",$login,$password); 
            self::$pdo = new PDO("mysql:host=$hostname;dbname=$database", $login, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
            } die();
        }
    }

    
    public static function selectAll() {                                        //on d�finit une fonction qui selectionne ls tuples d'une table
        $table_name = static::$object;                                          //cet obj r�cup�re le nom de la table d�finit dans le controller
        $model = 'Model' . ucfirst($table_name);                                //On g�n�re le nom du mod�le gr�ce � la var pr�c�dente

        $rep = Model::$pdo->query('SELECT * FROM ' . $table_name . '');         // notre requ�te
        $rep->setFetchMode(PDO::FETCH_CLASS, $model);                           //le type de notre model
        return $rep->fetchAll();
    }

    public static function select($primary_value) {                             //on d�finit une fonction qui s�lectionne les �l�ments associ�s � un param�tre
        $table_name = static::$object;                                      
        $model = 'Model' . ucfirst($table_name);
        $primary_key = static::$primary;                                        //en plus de pr�c�demment on r�cup�re une cl� primaire

        $sql = "SELECT * from $table_name WHERE $primary_key =:nom_tag";        //la cl� primaire r�cup�r�e permet d'effectuer la requ�te
        $req_prep = Model::$pdo->prepare($sql);
        $values = array(
            "nom_tag" => $primary_value                                         //le nom_tag permet de rendre "propre" la requ�te
        );
        $req_prep->execute($values);
        $req_prep->setFetchMode(PDO::FETCH_CLASS, $model);
        $tab_voit = $req_prep->fetchAll();
        if (empty($tab_voit)) {
            return false;
        }
        return $tab_voit[0];                                                    //on r�cup�re les valeurs
    }

    public static function delete($primary_value) {                             //on d�finit une fonction qui supprime les �l�ments associ�s � un param�tre
        $table_name = static::$object;
        $model = 'Model' . ucfirst($table_name);
        $primary_key = static::$primary;

        $sql = "DELETE FROM $table_name WHERE $primary_key =:nom_tag";
        $req_prep = Model::$pdo->prepare($sql);
        $values = array(
            "nom_tag" => $primary_value
        );
        $req_prep->setFetchMode(PDO::FETCH_CLASS, $model);
        $tab_voit = $req_prep->fetchAll();
        $req_prep->execute($values);
    }
/*
    public static function updated($data) {
        $table_name = static::$object;
        $model = 'Model' . ucfirst($table_name);
        $primary_key = static::$primary;
        
        $immat_id = $_GET['immatriculation'];
        $marq_id = $_POST['data'][0];
        $cou_id = $_POST['data'][1];

        foreach ($data as $cle){
            for ($i=0;$i<3;$i++){
                if ($cle==true) {
                $sql = "UPDATE $table_name SET immatriculation=:immat_tag";
                }
            }
            
        }
        
        
        $sql = "UPDATE $table_name SET immatriculation=:immat_tag, marque=:marq_tag, couleur=:cou_tag WHERE $primary_key=:immat_tag";
        $req_prep = Model::$pdo->prepare($sql);
        $values = array(
            "immat_tag" => $immat_id,
            "marq_tag" => $marq_id,
            "cou_tag" => $cou_id
        );
        $req_prep->execute($values);
    }
*/
}

Model::Init();                                                                  //on execute la fonction init qui fait appel � la bdd
