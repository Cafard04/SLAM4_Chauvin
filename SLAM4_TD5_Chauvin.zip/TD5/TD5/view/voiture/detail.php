
 <?php

        echo '<p> Voiture ' . htmlspecialchars($tab_v->getImmatriculation()). '.</p>';

     
     


 ?>

