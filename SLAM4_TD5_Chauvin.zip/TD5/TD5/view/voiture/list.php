
 <?php

     foreach ($tab_v as $v ){

        echo '<p> Voiture d\'immatriculation <a href="index.php?action=read&immatriculation='.rawurlencode($v->getImmatriculation()).'">' . htmlspecialchars($v->getImmatriculation()) . '</a>.</p>';
        
     }


 ?>
