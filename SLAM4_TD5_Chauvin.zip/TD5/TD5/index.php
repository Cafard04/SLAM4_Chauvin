<?php

require_once ('lib/File.php');

require_once (File::build_path(array("controller", "routeur.php")));