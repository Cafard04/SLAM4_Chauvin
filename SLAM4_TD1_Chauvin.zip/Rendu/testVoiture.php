<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8" />
        <title> Mon premier php </title>
        </head>

    <body>
        
     Liste des voitures :
     <?php
  include('voiture.php');
       
        $marque ="Renault";
        $couleur = "bleu";
        $immatriculation = "CCC";
        
      $voiture1 = new Voiture($marque, $couleur,$immatriculation);
        
       $voiture1->afficher();
     ?>
 </body>
</html>