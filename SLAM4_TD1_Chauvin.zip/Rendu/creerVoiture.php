<?php
if (empty($_POST['marque']) or empty($_POST['couleur']) or empty($_POST['immatriculation'])){
    echo "donnée manquante";
}
else {
    echo "Marque : ".$_POST['marque']. " Couleur : ".$_POST['couleur']." immat : ".$_POST['immatriculation'];
}
