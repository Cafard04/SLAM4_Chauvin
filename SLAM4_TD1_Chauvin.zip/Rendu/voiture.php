<?php
class Voiture {

 private $marque;
 private $couleur;
 private $immatriculation;

 // un getter
 public function getMarque() {
 return $this->marque;
 }

 // un setter
 public function setMarque($marque2) {
 $this->marque = $marque2;
 }
    
 // un getter
 public function getCouleur() {
 return $this->couleur;
 }

 // un setter
 public function setCouleur($couleur2) {
 $this->couleur = $couleur2;
 }

     // un getter
 public function getImmatriculation() {
    
 return $this->immatriculation;
 }

 // un setter
 public function setImmatriculation($immatriculation2) {
      if (strlen($immatriculation)>8){
         $immatriculation = substr($immatricualtion,0,7);
     }
 $this->immatriculation = $immatriculation2;
 }


 // un constructeur
 public function __construct($m, $c, $i) {
 $this->marque = $m;
 $this->couleur = $c;
 $this->immatriculation = $i;
 }

 // une methode d'affichage.
 public function afficher() {
 
     echo $this -> marque;
     echo $this -> couleur;
     echo $this -> immatriculation;
     
 }
    
   
}
?>