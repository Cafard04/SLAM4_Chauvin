<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8" />
        <title> Mon premier php </title>
        </head>

    <body>
     Liste des voitures :
     <?php
  
     $texte = "hello world !";

 
           
       $voiture = array(
            'marque' => 'Renault',
            'couleur' => 'bleu',
            'immatriculation' => 'VVVV'
        );
        
        
        
        $voitures =array([
            'marque' => 'Fiat',
            'couleur' => 'rose',
            'immatriculation' => 'SSSS'
        ],[
            'marque' => 'Zoe',
            'couleur' => 'noir',
            'immatriculation' => 'AAAA'
        ],[
            'marque' => 'Renault',
            'couleur' => 'bleu',
            'immatriculation' => 'FFFF'
        ]);
        
     // var_dump($voiture);

        
    
        
       
        foreach($voitures as $value)
    {
    echo "<ul>".$value['marque']." ". $value['couleur']." ".$value['immatriculation'].'</ul>';
            if (empty($value)) {
          echo "Il n'y a aucune valeur";
       }
    }

     ?>
 </body>
</html>