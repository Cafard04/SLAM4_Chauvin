<?php
/*
*
*
*
les trois modèles font appel à la classe modèle où les fonctions sont généralisées.
*
*
*
*/
require_once (File::build_path(array("model", "Model.php")));

class ModelVoiture extends Model{


 private $marque;
 private $couleur;
 private $immatriculation;
 protected static $object= 'voiture';
 protected static $primary='immatriculation';

 // un getter
 public function getMarque() {
 return $this->marque;
 }

 // un setter
 public function setMarque($marque2) {
 $this->marque = $marque2;
 }
    
 // un getter
 public function getCouleur() {
 return $this->couleur;
 }

 // un setter
 public function setCouleur($couleur2) {
 $this->couleur = $couleur2;
 }

     // un getter
 public function getImmatriculation() {
    
 return $this->immatriculation;
 }

 // un setter
 public function setImmatriculation($immatriculation) {
      if (strlen($immatriculation)>8){
         $immatriculation = substr($immatriculation,0,8);
     }
    $this->immatriculation = $immatriculation;
 }


 // un constructeur
public function __construct($m = NULL, $c = NULL, $i = NULL) {
        if (!is_null($m) && !is_null($c) && !is_null($i)) {
            $this->marque = $m;
            $this->couleur = $c;
            $this->immatriculation = $i; 
            
        } 
      
    }






 
   
}


    
