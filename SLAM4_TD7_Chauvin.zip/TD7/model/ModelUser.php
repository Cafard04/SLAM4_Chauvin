<?php
/*
*
*
*
les trois mod�les font appel � la classe mod�le o� les fonctions sont g�n�ralis�es.
*
*
*
*/
require_once (File::build_path(array("model", "Model.php")));

class ModelUser extends Model{                                                  //extension du Model


 private $login;
 private $nom;
 private $prenom;
 protected static $object = 'user';                                             //objet r�utilis� dans le Model pour d�finir le nom de la table
  protected static $primary='login';                                            //objet r�utilis� dans le Model pour d�finir la cl� primaire

 // un getter
 public function getLogin() {
 return $this->login;
 }

 // un setter
 public function setLogin($login2) {
 $this->login = $login2;
 }
    
 // un getter
 public function getNom() {
 return $this->nom;
 }

 // un setter
 public function setNom($nom2) {
 $this->nom = $nom2;
 }

     // un getter
 public function getPrenom() {
    
 return $this->prenom;
 }

 // un setter
 public function setPrenom($prenom) {
      
    $this->prenom = $prenom;
 }


 // un constructeur
public function __construct($l = NULL, $n = NULL, $p = NULL) {
        if (!is_null($l) && !is_null($n) && !is_null($p)) {
            $this->login = $l;
            $this->nom = $n;
            $this->prenom = $p; 
            
        } 
    }

 
}