<?php

require_once (File::build_path(array("model", "Model.php")));

class ModelUser extends Model{                                                  //extension du Model


 private $login;
 private $nom;
 private $prenom;
 protected static $object = 'user';                                             //objet r�utilis� dans le Model pour d�finir le nom de la table
  protected static $primary='login';                                            //objet r�utilis� dans le Model pour d�finir la cl� primaire

 // un getter
 public function getLogin() {
 return $this->login;
 }

 // un setter
 public function setLogin($login2) {
 $this->login = $login2;
 }
    
 // un getter
 public function getNom() {
 return $this->nom;
 }

 // un setter
 public function setNom($nom2) {
 $this->nom = $nom2;
 }

     // un getter
 public function getPrenom() {
    
 return $this->prenom;
 }

 // un setter
 public function setPrenom($prenom) {
      
    $this->prenom = $prenom;
 }


 // un constructeur
public function __construct($l = NULL, $n = NULL, $p = NULL) {
        if (!is_null($l) && !is_null($n) && !is_null($p)) {
            $this->login = $l;
            $this->nom = $n;
            $this->prenom = $p; 
            
        } 
    }

   /* 
 public static function save($login, $nom, $prenom){                            //une fonction qui insert un tuple dans la bdd
    $login=$_POST['login'];
    $nom=$_POST['data'][0];
    $prenom=$_POST['data'][1];
    
    $sql="INSERT INTO user VALUES (:login_tag, :nom_tag, :prenom_tag)";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "nom_tag" => $nom,
        "prenom_tag" => $prenom,
        "login_tag" =>$login
    );
    $req_prep->execute($values);
 }
 */
 
public static function updated($data){                                          //fonction qui met � jour des champs selon un id pass� en param�tre
    $login=$_GET['login'];
    $nom=$_POST['data'][0];
    $prenom=$_POST['data'][1];
    
    $sql="UPDATE user SET login=:login_tag, nom=:nom_tag, prenom=:prenom_tag WHERE login=:login_tag";
    $req_prep = Model::$pdo->prepare($sql);
    $values = array(
        "login_tag" => $login,
        "nom_tag" => $nom,
        "prenom_tag" => $prenom
    );
    $req_prep->execute($values);
}

 /* //On g�n�ralise avec le selectAll() dans model.php
 public static function getAllUsers(){
     $rep = Model::$pdo->query('SELECT * FROM users'); 
     $rep->setFetchMode(PDO::FETCH_CLASS, 'ModelUser'); 
      return  $rep->fetchAll();

 }*/
}