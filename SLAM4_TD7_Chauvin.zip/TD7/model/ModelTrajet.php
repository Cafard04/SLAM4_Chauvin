<?php
/*
*
*
*
les trois modèles font appel à la classe modèle où les fonctions sont généralisées.
*
*
*
*/
require_once (File::build_path(array("model", "Model.php")));

class ModelTrajet extends Model{                                                  //extension du Model


 private $id;
 private $depart;
 private $arrivee;
 private $dateT;
 private $nbplaces;
 private $prix;
    private $cond_log;
    
 protected static $object = 'trajet';                                             //objet réutilisé dans le Model pour définir le nom de la table
  protected static $primary='id';                                            //objet réutilisé dans le Model pour définir la clé primaire

 // un getter
 public function getId() {
 return $this->id;
 }

 // un setter
 public function setId($id2) {
 $this->id = $id2;
 }
    
 // un getter
 public function getDepart() {
 return $this->depart;
 }

 // un setter
 public function setDepart($depart2) {
 $this->depart = $depart2;
 }

     // un getter
 public function getArrivee() {
    
 return $this->arrivee;
 }

 // un setter
 public function setArrivee($arrivee) {
      
    $this->arrivee = $arrivee;
 }

         // un getter
 public function getdateT() {
    
 return $this->dateT;
 }

 // un setter
 public function setdateT($dateT) {
      
    $this->dateT = $dateT;
 }
         // un getter
 public function getNbplaces() {
    
 return $this->nbplaces;
 }

 // un setter
 public function setNbplaces($nbplaces) {
      
    $this->nbplaces = $nbplaces;
 }
         // un getter
 public function getPrix() {
    
 return $this->prix;
 }

 // un setter
 public function setPrix($prix) {
      
    $this->prix = $prix;
 }
             // un getter
 public function getCond() {
    
 return $this->cond_log;
 }

 // un setter
 public function setCond($cond_log) {
      
    $this->cond_log = $cond_log;
 }

 // un constructeur
public function __construct($i = NULL, $d = NULL, $a = NULL, $da = NULL, $nb =NULL, $p = NULL, $c = NULL) {
        if (!is_null($i) && !is_null($d) && !is_null($a) && !is_null($da) && !is_null($nb) && !is_null($p) && !is_null($c)) {
            $this->id = $i;
            $this->depart = $d;
            $this->arrivee = $a; 
            $this->dateT = $da;
            $this->nbplaces = $nb;
            $this->prix = $p;
            $this->cond_log = $c;
            
        } 
    }

  


}