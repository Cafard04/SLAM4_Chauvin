<?php
                           
$tableau = array("cookies","chocolat","glace");
$tableau_serialize = serialize($tableau);
 
setcookie("TestCookie", $tableau_serialize, time()+3600);

$tab_cookies = unserialize($_COOKIE['TestCookie']);

//setcookie ("TestCookie", "", time() - 1);

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Cookies</title>
    </head>
    <body>
    
        voici un test
        <br>
        <?php print_r($tab_cookies)?>
    </body>
</html>