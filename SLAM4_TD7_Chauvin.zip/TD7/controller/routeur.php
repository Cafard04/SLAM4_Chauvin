<?php

require_once (File::build_path(array("controller", "ControllerVoiture.php")));  //on requiert le controller voiture
require_once (File::build_path(array("controller", "ControllerUser.php")));     //on requiert le controller user
require_once (File::build_path(array("controller", "ControllerTrajet.php"))); 
// On recup�re l'action pass�e dans l'URL

//$controller_default = "voiture";
//$controller_default = $_COOKIE['cookies'];

if (isset($_GET['controller'])) {                                               //on v�rifie l'existance d'un controller
    $controller = $_GET['controller'];
    $controller_class = 'Controller' . ucfirst($controller);                    //on g�n�re le nom du controller - ucfirst() met en majuscule la premi�re lettre d'un mot
    if (isset($_GET['action'])) {                                               //on v�rifie l'existance d'une action dans le controller
        $action = $_GET['action'];
        $controller_class::$action();                                           //on execute une action selon un controller
    } else {
        $controller_class::readAll();
    }

    /*   if (class_exists($controller_class)) {
      $myclass = new $controller_class();
      } */
} else {
    require 'view/preferences.php';                                                //si un param�tre n'est pas respect� on affiche un msg d'erreur
}




//$action='readAll';




