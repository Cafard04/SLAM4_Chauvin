<?php 


require_once (File::build_path(array("model", "ModelTrajet.php"))); // chargement du modèle

class ControllerTrajet {
    
    protected static $object = 'trajet';
        protected static $action;
    protected static $type;
    
    public static function readAll() {
        $tab_v = ModelTrajet::selectAll(); //appel au modèle pour gerer la BD
        $controller=static::$object;
        $view='list';
        $pagetitle='Liste des trajets';
        require (File::build_path(array("view", "view.php"))); //"redirige" vers la vue
    }
    
        
    public static function read() {
        $controller=static::$object;
        $view='detail_U';
        $pagetitle='Détail des trajets';
        $tab_v = ModelTrajet::select($_GET['id']); //appel au modèle pour gerer la BD
       
        if ($_GET['id']==NULL){
            require (File::build_path(array("view","voiture", "error.php")));//"redirige" vers la vue
        } else {
             require (File::build_path(array("view","trajet", "detail_T.php")));//"redirige" vers la vue
        }
      
        
    }
    
    
    public static function delete() {
        $controller = static::$object;
        $view = 'deleted_U';
        $pagetitle = 'Suppression d\'un trajet';

        $tab_v = ModelTrajet::delete($_GET['id']);

        if ($_GET['id'] == NULL) {
            require (File::build_path(array("view", "voiture", "error.php"))); //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "trajet", "deleted_T.php"))); //"redirige" vers la vue
        }
    }
    
    
     public static function create() {
        static::$action='created';
        static::$type ='required';
        
        require (File::build_path(array("view", "trajet", "update_T.php")));
    }

     public static function created() {
        $controller =static::$object;
        $view = 'created';
        $pagetitle = 'Création des trajets';

        ModelTrajet::save($_POST['data']);
        $tab_v = ModelTrajet::selectAll();
        require (File::build_path(array("view", "trajet", "created_T.php")));
    }
    
    
    public static function updated() {
        static::$action='updated';
        static::$type ='readonly';
        $controller = 'trajet';
        $view = 'update';
        $pagetitle = 'Modification d\'un trajet';
        
        ModelTrajet::update($_POST['data'],$_GET['id']);
        $tab_v = ModelTrajet::select($_GET['id']);

        if ($_GET['id'] == NULL) {
            require (File::build_path(array("view", "trajet", "error.php")));  //"redirige" vers la vue
        } else {
            require (File::build_path(array("view", "trajet", "update_T.php")));
        }
    }

    public static function update() {
        static::$action='updated';
        static::$type ='readonly';
        
        
        
      $controller = static::$object;
      $view = 'update';
      $pagetitle = 'Modification d\'un trajet';

      $tab_v = ModelTrajet::select($_GET['id']);
      require (File::build_path(array("view", "trajet", "update_T.php")));
      

      /*if ($_GET['immatriculation'] == NULL) {
      require (File::build_path(array("view", "voiture", "error.php"))); //"redirige" vers la vue
      } else {
      require (File::build_path(array("view", "voiture", "update.php")));
      }*/
      }
    

    
    
    
   }
