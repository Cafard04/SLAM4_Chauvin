<?php 


require_once (File::build_path(array("model", "ModelTrajet.php")));                             // chargement du modèle

class ControllerTrajet {
    
    protected static $object = 'trajet';
        protected static $action;
    protected static $type;
    
    public static function readAll() {
        $tab_v = ModelTrajet::selectAll();                                                      //les informations récupérées lors de l'appel de la fonction selectAll() sont sotcvkées dans un tableau                                                   
        $controller=static::$object;                                                            //le controller récupère la valeur de la variable initialisée avant
        $view='list';                                                                           //donner une valeur à la vue et au titre de la page
        $pagetitle='Liste des trajets';
        require (File::build_path(array("view", "view.php")));                                  //on récupère la page view.php qui elle même récupère les variables juste ci-dessus.                          
    }   
    
        
    public static function read() {
        $controller=static::$object;
        $view='detail_U';
        $pagetitle='Détail des trajets';
        $tab_v = ModelTrajet::select($_GET['id']);                                              //appel au modèle pour gerer la BD avec un paramètre
       
        if ($_GET['id']==NULL){                                                                 //si l'identifiant est null dans l'url on redirige
            require (File::build_path(array("view","voiture", "error.php")));                   //"redirige" vers la vue
        } else {                                                                                //sinon
             require (File::build_path(array("view","trajet", "detail_T.php")));                //"redirige" vers la vue
        }
      
        
    }
    
    
    public static function delete() {
        $controller = static::$object;
        $view = 'deleted_U';
        $pagetitle = 'Suppression d\'un trajet';

        $tab_v = ModelTrajet::delete($_GET['id']);

        if ($_GET['id'] == NULL) {
            require (File::build_path(array("view", "voiture", "error.php")));                 
        } else {
            require (File::build_path(array("view", "trajet", "deleted_T.php")));                  
        }
    }
    
    
     public static function create() {
        static::$action='created';
        static::$type ='required';
        
        require (File::build_path(array("view", "trajet", "update_T.php")));
    }

     public static function created() {
        $controller =static::$object;
        $view = 'created';
        $pagetitle = 'Création des trajets';

        ModelTrajet::save($_POST['data']);
        $tab_v = ModelTrajet::selectAll();
        require (File::build_path(array("view", "trajet", "created_T.php")));
    }
    
    
    public static function updated() {
        static::$action='updated';
        static::$type ='readonly';
        $controller = 'trajet';
        $view = 'update';
        $pagetitle = 'Modification d\'un trajet';
        
        ModelTrajet::update($_POST['data'],$_GET['id']);
        $tab_v = ModelTrajet::select($_GET['id']);

        if ($_GET['id'] == NULL) {
            require (File::build_path(array("view", "trajet", "error.php"))); 
        } else {
            require (File::build_path(array("view", "trajet", "update_T.php")));
        }
    }

    public static function update() {
        static::$action='updated';
        static::$type ='readonly';
        
        
        
      $controller = static::$object;
      $view = 'update';
      $pagetitle = 'Modification d\'un trajet';

      $tab_v = ModelTrajet::select($_GET['id']);
      require (File::build_path(array("view", "trajet", "update_T.php")));
      

      }
    

    
    
    
   }
