<?php include 'personnalisation.php';

echo $_COOKIE['cookies'];