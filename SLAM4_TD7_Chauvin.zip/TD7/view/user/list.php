
 <?php

     foreach ($tab_v as $v ){

        echo '<p> User : <a href="index.php?controller=user&action=read&login='.rawurlencode($v->getLogin()).'">'. htmlspecialchars($v->getNom()).'</a>.';
        //on prot�ge notre code gr�ce au methode rawurlencode() et htmlspecialcar()
   }


 ?>

