
<form method="post" action="index.php?controller=voiture&action=<?= static::$action ?><?php if (static::$action =="updated") echo '&immatriculation='.$_GET['immatriculation'];?>">
  
    
   <fieldset>
 <legend>Mon formulaire :</legend>
 <p>
 <label for="immat_id">Immatriculation</label> :
 <input type="text" placeholder="<?php if (static::$action =="updated") echo $_GET['immatriculation']; ?>" name="data[immatriculation]" id="immatriculation" <?= static::$type?>/>

 </p>
      <p>
 <label for="marq_id">Marque</label> :
 <input type="text" placeholder="<?php if (static::$action =="updated") echo $tab_v->getMarque()?>" name="data[marque]" id="marque " required/>
 </p>
      <p>
 <label for="cou_id">Couleur</label> :
 <input type="text" placeholder="<?php if (static::$action =="updated") echo $tab_v->getCouleur()?>" name="data[couleur]" id="couleur" required/>
 </p>
     

 <p>
 <input type="submit" value="Envoyer" />
 </p>
 </fieldset>
</form>



