<?php
//on stocke dans cette page les choix de l'utilisateur et on  le redirige en conséquence
session_start();

$_SESSION['choix'] = $_POST['choix'];

setcookie("choix", $_SESSION['choix'], time()+3600); 

echo $_COOKIE["choix"];

header('Location: ../index.php?controller='.$_COOKIE["choix"].'&action=readAll');