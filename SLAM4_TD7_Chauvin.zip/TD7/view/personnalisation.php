<?php

session_start();

$_SESSION['choix'] = $_POST['choix'];

setcookie("choix", $_SESSION['choix'], time()+3600); 

echo $_COOKIE["choix"];

header('Location: ../index.php?controller='.$_COOKIE["choix"].'&action=readAll');