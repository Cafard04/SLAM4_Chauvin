
 <?php

        echo '<p> Trajet :  ' . htmlspecialchars($tab_v->getId()). ' pour la date du '.htmlspecialchars($tab_v->getdateT()).' par l\'utilisateur '. htmlspecialchars($tab_v->getCond()).'. </p>'.
                 '<a href="index.php?controller=trajet&action=delete&id='.$tab_v->getId().'">Supprimer ce trajet</a>'
                . '<br><a href="index.php?controller=trajet&action=update&id='.$tab_v->getId().'">Modifier ce trajet</a>';
                //si dessus les liens pour rediriger vers d'autres actions
                
