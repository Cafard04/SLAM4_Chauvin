<!-- cette page est commune � 2 action cr�er et modifier, on insere donc des conditions -->
<form method="post" action="index.php?controller=trajet&action=<?= static::$action ?><?php if (static::$action =='updated') echo '&id='.$_GET['id'];?>">
                                                                                <!-- l'action change selon la donn�e rentr�e dans la m�me varibale d�finie dans le controller -->
   <fieldset>
 <legend>Mon formulaire :</legend>
 <p>
 <label for="id">Id</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $_GET['id']; ?>" name="data[id]" id="id" <?= static::$type?>/>
 </p>                                                                           <!--  si l'action est "updated alors on affiche une donn�e-->
                                                                                <!-- on change �galement le type de l'input readonly ou required-->
      <p>
 <label for="depart">Depart</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $tab_v->getDepart()?>" name="data[depart]" id="depart " />
 </p>                                                                           <!-- on stocke la donn�e dans un tableau -->
      <p>
 <label for="arrivee">Arriv�e</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $tab_v->getArrivee()?>" name="data[arrivee]" id="arrivee" />
 </p>
       <p>
 <label for="dateT">Date</label> :
 <input type="date" value="<?php if (static::$action =="updated") echo $tab_v->getdateT()?>" name="data[dateT]" id="dateT" />
 </p>
       <p>
 <label for="nbplaces">Nb de place</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $tab_v->getNbplaces()?>" name="data[nbplaces]" id="nbplaces" />
 </p>
       
       <p>
 <label for="prix">Prix</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $tab_v->getPrix()?>" name="data[prix]" id="prix" />
 </p>
       
       <p>
 <label for="cond">Conducteur</label> :
 <input type="text" value="<?php if (static::$action =="updated") echo $tab_v->getCond()?>" name="data[cond_log]" id="cond" />
 </p>
       
       
     

 <p>
 <input type="submit" value="Envoyer" />
 </p>
 </fieldset>
</form>


