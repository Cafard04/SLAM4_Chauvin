<?php

echo '<p> User effac� avec succ�s.</p>';
