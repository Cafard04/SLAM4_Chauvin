<?php

class File{
    const DS = DIRECTORY_SEPARATOR;                                                     //passer d'une plateforme à une autre facilement, équivalent de "/"
    const ROOT_FOLDER = __DIR__.self::DS."..";                                          //obtient le chemin absolu (racine) du projet
    
    public static function build_path($path_array) {

        return self::ROOT_FOLDER.self::DS. join(self::DS, $path_array);                 //on parcourt l'arborescence des fichers (dossier, dossier2_si_existe, nom_du_ficher)
    }
    
    
}