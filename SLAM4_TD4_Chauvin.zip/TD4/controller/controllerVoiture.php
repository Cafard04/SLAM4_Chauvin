<?php 


require_once ('../model/ModelVoiture.php'); // chargement du mod�le
class ControllerVoiture {
    public static function readAll() {
        $tab_v = ModelVoiture::getAllVoitures(); //appel au mod�le pour gerer la BD
        require ('../view/voiture/list.php'); //"redirige" vers la vue
    }
    
    
    public static function read() {
        $tab_v = ModelVoiture::getVoitureByImmat($_GET['immatriculation']); //appel au mod�le pour gerer la BD
       
        if ($_GET['immatriculation']==NULL){
            require ("..view/voiture/error.php");//"redirige" vers la vue
        } else {
             require ("..view/voiture/detail.php");
        }
      
        
    }
    public static function erreur() {
        require ('../view/voiture/error.php'); //"redirige" vers la vue
    }
    
    public static function create() {
        require ('../view/voiture/create.php'); //"redirige" vers la vue
    }
    
    public static function created() {
        ModelVoiture::save($_POST['marque'],$_POST['couleur'],$_POST['immatriculation']);
        
        header("Location:routeur.php?action=readAll"); //"redirige" vers la vue
    }
    
    
    
    
}
