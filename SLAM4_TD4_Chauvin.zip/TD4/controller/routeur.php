<?php 

require_once 'ControllerVoiture.php';
// On recup�re l'action pass�e dans l'URL

$action = $_GET['action'];
//$action='readAll';
ControllerVoiture::$action();


