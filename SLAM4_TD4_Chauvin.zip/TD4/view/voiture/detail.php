 <head>

 <meta charset="UTF-8">
 <title>D�tail voitures</title>
 </head>
 <body>
 <?php

     foreach ($tab_v as $v ){
        echo '<p> Voiture' . $v. '.</p>';
        
     }
     
     


 ?>
 </body>
